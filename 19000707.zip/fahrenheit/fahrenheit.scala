object fahrenheit extends App{
    def convert(x:Double)=x*1.8+32;
	println(convert(35));
}
