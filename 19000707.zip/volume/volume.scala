object volume extends App{
	def vol(r:Double):Double=(4/3)*math.Pi*math.pow(r,3);
	println(vol(5));
}