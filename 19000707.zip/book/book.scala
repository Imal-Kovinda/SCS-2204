object book extends App{
    var paper:Int = 60;
    val Dis:Double=0.4;
    val c_price:Double=24.95;
    
    def cover_price(cover:Int):Double=cover*c_price;

    def discount(price:Double):Double=price*Dis;

    def shipping_cost_less50(p:Double):Double=p*3

    def shipping_cost_greater50(p:Double):Double=p*3+(p-50)*0.75


    if(paper<50){
        var total_price:Double=cover_price(paper) - discount(cover_price(paper)) + shipping_cost_less50(paper);
        print("Total Price: Rs. ");
        println(total_price);
    }
    else{
        var total_price:Double=cover_price(paper) - discount(cover_price(paper)) + shipping_cost_greater50(paper);
        print("Total Price: Rs. ");
        println(total_price);
    }
}